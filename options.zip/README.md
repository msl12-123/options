# IV Surface — Derivatives Analytics

A professional 3D implied volatility surface explorer built for options analysis.  
Charcoal terminal aesthetic · IBM Plex type · Gold accents · Live Yahoo Finance data.

---

## Why a local server?

Browser-based apps cannot fetch directly from Yahoo Finance due to **CORS restrictions** — browsers block cross-origin requests as a security policy. Free CORS proxy services are unreliable and rate-limited.

This app solves it with a tiny local Node.js server (`server.js`) that:
- Makes Yahoo Finance requests server-side (no CORS restrictions)
- Serves the frontend files
- Exposes a clean REST API at `localhost:3000/api/`
- Has **zero npm dependencies** — uses only Node.js built-ins

---

## Quick Start

### Requirements
- **Node.js 18 or newer** — download from [nodejs.org](https://nodejs.org) (LTS recommended)
- No `npm install` needed

### Mac / Linux
```bash
cd options-3d-viz
chmod +x start.sh
./start.sh
```

### Windows
```
Double-click start.bat
```

### Manual (any OS)
```bash
node server.js
# Then open http://localhost:3000
```

---

## API Endpoints

| Endpoint | Description |
|---|---|
| `GET /api/quote?ticker=AAPL` | Current quote |
| `GET /api/expirations?ticker=AAPL` | All expiration timestamps |
| `GET /api/chain?ticker=AAPL&exp=1735689600` | Option chain for one expiry |
| `GET /api/health` | Server health check |

---

## Project Structure

```
options-3d-viz/
├── server.js      <- Node.js backend (run this first)
├── index.html     <- App shell and layout
├── style.css      <- Terminal design system
├── data.js        <- Fetches from local server, builds IV surface grid
├── viz3d.js       <- Three.js 3D surface renderer
├── app.js         <- UI controller, charts, panels
├── start.sh       <- Mac/Linux launcher
├── start.bat      <- Windows launcher
└── README.md
```

---

## Upgrading to Production Data

Replace the Yahoo Finance fetch calls in `server.js` with Polygon.io, Tradier, or CBOE DataShop. Only `server.js` needs to change — the frontend is provider-agnostic.

---

MIT License
