/**
 * server.js — Local Options Data Server
 *
 * Run with:  node server.js
 * Then open: http://localhost:3000
 *
 * This server fetches Yahoo Finance data server-side (no CORS restrictions),
 * exposes a clean REST API, and serves the frontend static files.
 *
 * Requirements:  Node.js 18+  (uses built-in fetch)
 * No npm install needed — zero external dependencies.
 */

'use strict';

const http  = require('http');
const https = require('https');
const fs    = require('fs');
const path  = require('path');
const url   = require('url');

const PORT    = 3000;
const YF_HOST = 'query1.finance.yahoo.com';

// ─── Yahoo Finance fetcher (server-side, no CORS) ─────────────────────────────
function yfetch(ypath) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: YF_HOST,
      path:     ypath,
      method:   'GET',
      headers: {
        'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept':          'application/json, text/plain, */*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'identity',
        'Cache-Control':   'no-cache',
        'Referer':         'https://finance.yahoo.com',
        'Origin':          'https://finance.yahoo.com',
      },
      timeout: 12000,
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode === 200) {
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            reject(new Error('JSON parse error: ' + e.message));
          }
        } else {
          reject(new Error(`Yahoo Finance returned HTTP ${res.statusCode}`));
        }
      });
    });

    req.on('error',   e => reject(new Error('Network error: ' + e.message)));
    req.on('timeout', () => { req.destroy(); reject(new Error('Request timed out')); });
    req.end();
  });
}

// ─── MIME types for static files ──────────────────────────────────────────────
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css':  'text/css; charset=utf-8',
  '.js':   'application/javascript; charset=utf-8',
  '.json': 'application/json',
  '.png':  'image/png',
  '.ico':  'image/x-icon',
};

// ─── CORS headers ─────────────────────────────────────────────────────────────
function setCORS(res) {
  res.setHeader('Access-Control-Allow-Origin',  '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

// ─── JSON response helpers ────────────────────────────────────────────────────
function jsonOK(res, data) {
  setCORS(res);
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data));
}

function jsonErr(res, code, msg) {
  setCORS(res);
  res.writeHead(code, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: msg }));
}

// ─── API handlers ─────────────────────────────────────────────────────────────

async function handleQuote(res, ticker) {
  try {
    const data = await yfetch(`/v8/finance/chart/${ticker}?interval=1d&range=1d`);
    const m    = data.chart.result[0].meta;
    const prev = m.previousClose || m.chartPreviousClose || m.regularMarketPrice;
    jsonOK(res, {
      ticker:    ticker.toUpperCase(),
      price:     m.regularMarketPrice,
      prev,
      change:    m.regularMarketPrice - prev,
      changePct: ((m.regularMarketPrice - prev) / prev) * 100,
      currency:  m.currency,
      exchange:  m.exchangeName,
      name:      m.shortName || m.longName || ticker,
      mktCap:    m.marketCap  || null,
      volume:    m.regularMarketVolume || null,
      high52:    m.fiftyTwoWeekHigh   || null,
      low52:     m.fiftyTwoWeekLow    || null,
    });
  } catch (e) {
    jsonErr(res, 502, 'Quote fetch failed: ' + e.message);
  }
}

async function handleExpirations(res, ticker) {
  try {
    const data = await yfetch(`/v7/finance/options/${ticker}`);
    const result = data.optionChain.result[0];
    jsonOK(res, { expirationDates: result.expirationDates });
  } catch (e) {
    jsonErr(res, 502, 'Expirations fetch failed: ' + e.message);
  }
}

async function handleChain(res, ticker, expTs) {
  try {
    const data = await yfetch(`/v7/finance/options/${ticker}?date=${expTs}`);
    const opts  = data.optionChain.result[0].options[0];
    jsonOK(res, {
      calls: opts.calls || [],
      puts:  opts.puts  || [],
    });
  } catch (e) {
    jsonErr(res, 502, 'Chain fetch failed: ' + e.message);
  }
}

// ─── Static file server ───────────────────────────────────────────────────────
function serveStatic(res, filePath) {
  const ext      = path.extname(filePath).toLowerCase();
  const mimeType = MIME[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not found');
      return;
    }
    res.writeHead(200, { 'Content-Type': mimeType });
    res.end(data);
  });
}

// ─── Request router ───────────────────────────────────────────────────────────
const server = http.createServer((req, res) => {
  const parsed = url.parse(req.url, true);
  const pathname = parsed.pathname;
  const query    = parsed.query;

  // Handle preflight
  if (req.method === 'OPTIONS') {
    setCORS(res);
    res.writeHead(204);
    res.end();
    return;
  }

  // API routes
  if (pathname === '/api/quote') {
    if (!query.ticker) return jsonErr(res, 400, 'Missing ticker');
    return handleQuote(res, query.ticker.toUpperCase().replace(/[^A-Z0-9.]/g, ''));
  }

  if (pathname === '/api/expirations') {
    if (!query.ticker) return jsonErr(res, 400, 'Missing ticker');
    return handleExpirations(res, query.ticker.toUpperCase().replace(/[^A-Z0-9.]/g, ''));
  }

  if (pathname === '/api/chain') {
    if (!query.ticker || !query.exp) return jsonErr(res, 400, 'Missing ticker or exp');
    return handleChain(res, query.ticker.toUpperCase().replace(/[^A-Z0-9.]/g, ''), query.exp);
  }

  // Health check
  if (pathname === '/api/health') {
    return jsonOK(res, { status: 'ok', time: new Date().toISOString() });
  }

  // Static files — serve from same directory as server.js
  const safePath = path.normalize(pathname).replace(/^(\.\.(\/|\\|$))+/, '');
  let   filePath = path.join(__dirname, safePath === '/' ? 'index.html' : safePath);

  // Default to index.html for unknown routes
  if (!path.extname(filePath)) filePath = path.join(__dirname, 'index.html');

  serveStatic(res, filePath);
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('');
  console.log('  ╔══════════════════════════════════════════╗');
  console.log('  ║   IV Surface — Derivatives Analytics     ║');
  console.log('  ╚══════════════════════════════════════════╝');
  console.log('');
  console.log(`  Server running at → http://localhost:${PORT}`);
  console.log('');
  console.log('  Open that URL in your browser.');
  console.log('  Press Ctrl+C to stop.');
  console.log('');
});

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.error(`\n  ERROR: Port ${PORT} is already in use.`);
    console.error(`  Try:  node server.js ${PORT + 1}\n`);
  } else {
    console.error('Server error:', e.message);
  }
  process.exit(1);
});
