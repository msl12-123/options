/**
 * data.js — Market Data Client
 *
 * Talks to the local Node.js server (server.js) which fetches
 * Yahoo Finance server-side — no CORS, no proxies, no rate limits.
 *
 * API base: http://localhost:3000/api/
 */

'use strict';

const API = 'http://localhost:3000/api';

// ─── Market Average ATM IV by DTE (SPY/QQQ 5yr rolling) ──────────────────────
const MKT_AVG_IV = {
  7: 0.175, 14: 0.168, 21: 0.163, 30: 0.165,
  45: 0.170, 60: 0.174, 90: 0.180, 120: 0.186,
  180: 0.194, 270: 0.202, 365: 0.212,
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
function calcDTE(unixTs) {
  return Math.max(0, Math.round((unixTs - Date.now() / 1000) / 86400));
}

function fmtDate(ts) {
  return new Date(ts * 1000).toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric'
  });
}

function mktAvgIV(dte) {
  const keys = Object.keys(MKT_AVG_IV).map(Number).sort((a, b) => a - b);
  if (dte <= keys[0])                return MKT_AVG_IV[keys[0]];
  if (dte >= keys[keys.length - 1]) return MKT_AVG_IV[keys[keys.length - 1]];
  for (let i = 0; i < keys.length - 1; i++) {
    if (dte >= keys[i] && dte <= keys[i + 1]) {
      const t = (dte - keys[i]) / (keys[i + 1] - keys[i]);
      return MKT_AVG_IV[keys[i]] * (1 - t) + MKT_AVG_IV[keys[i + 1]] * t;
    }
  }
  return MKT_AVG_IV[30];
}

function expMove(price, iv, dte)  { return price * iv * Math.sqrt(dte / 365); }
function expMovePct(iv, dte)      { return iv * Math.sqrt(dte / 365); }

// ─── API fetch wrapper ────────────────────────────────────────────────────────
async function apiFetch(endpoint) {
  let res;
  try {
    res = await fetch(API + endpoint, { cache: 'no-store' });
  } catch (e) {
    throw new Error(
      'Cannot reach local server. Make sure you ran: node server.js\n' +
      'Then open http://localhost:3000 in your browser.'
    );
  }
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Server returned HTTP ${res.status}`);
  }
  return res.json();
}

// ─── Contract processing ──────────────────────────────────────────────────────
function processContracts(calls, puts, contractType, price, expTs) {
  const dte  = calcDTE(expTs);
  const date = fmtDate(expTs);
  const avg  = mktAvgIV(dte);
  const out  = [];

  const push = (list, type) => {
    for (const c of list) {
      const iv = c.impliedVolatility;
      if (!iv || iv <= 0 || iv > 6) continue;
      if (!c.strike) continue;

      const mn = c.strike / price;
      if (mn < 0.55 || mn > 1.55) continue;

      out.push({
        type,
        ticker:      null,
        strike:      c.strike,
        moneyness:   mn,
        dte,
        expDate:     date,
        expTs,
        iv,
        marketAvgIV: avg,
        ivVsAvg:     avg > 0 ? (iv - avg) / avg : 0,
        em:          expMove(price, iv, dte),
        emPct:       expMovePct(iv, dte),
        volume:      c.volume        || 0,
        oi:          c.openInterest  || 0,
        bid:         c.bid           || 0,
        ask:         c.ask           || 0,
        last:        c.lastPrice     || 0,
        symbol:      c.contractSymbol || '',
        itm:         c.inTheMoney    || false,
      });
    }
  };

  if (contractType === 'calls' || contractType === 'both') push(calls, 'call');
  if (contractType === 'puts'  || contractType === 'both') push(puts,  'put');
  return out;
}

// ─── IV surface grid (Gaussian kernel interpolation) ─────────────────────────
function buildIVSurface(contracts) {
  const mRange = [];
  for (let m = 0.72; m <= 1.31; m += 0.02) mRange.push(parseFloat(m.toFixed(2)));

  const dteSet   = new Set(contracts.map(c => c.dte));
  const dteRange = Array.from(dteSet).sort((a, b) => a - b);
  if (dteRange.length < 2) return null;

  const grid = dteRange.map(dte => {
    const slice = contracts.filter(c => c.dte === dte);
    if (!slice.length) return mRange.map(() => null);

    return mRange.map(m => {
      const nearby = slice
        .map(c => ({ iv: c.iv, dist: Math.abs(c.moneyness - m) }))
        .filter(c => c.dist < 0.12)
        .sort((a, b) => a.dist - b.dist)
        .slice(0, 6);

      if (!nearby.length) return null;

      let sumW = 0, sumIV = 0;
      for (const c of nearby) {
        const w = Math.exp(-(c.dist * c.dist) / (2 * 0.003));
        sumW  += w;
        sumIV += w * c.iv;
      }
      return sumW > 0 ? sumIV / sumW : null;
    });
  });

  // Fill gaps via linear interpolation along moneyness axis
  for (let di = 0; di < dteRange.length; di++) {
    const row = grid[di];
    for (let mi = 0; mi < row.length; mi++) {
      if (row[mi] !== null) continue;
      let lo = mi - 1, hi = mi + 1;
      while (lo >= 0 && row[lo] === null) lo--;
      while (hi < row.length && row[hi] === null) hi++;
      if (lo >= 0 && hi < row.length) {
        row[mi] = row[lo] + (row[hi] - row[lo]) * ((mi - lo) / (hi - lo));
      } else if (lo >= 0)           { row[mi] = row[lo]; }
        else if (hi < row.length)   { row[mi] = row[hi]; }
    }
  }

  return { grid, mRange, dteRange };
}

// ─── Market average reference surface ────────────────────────────────────────
function buildMarketAvgSurface() {
  const mRange   = [];
  for (let m = 0.72; m <= 1.31; m += 0.02) mRange.push(parseFloat(m.toFixed(2)));
  const dteRange = [7, 14, 21, 30, 45, 60, 90, 120, 180, 270, 365];

  const grid = dteRange.map(dte =>
    mRange.map(m => {
      const d     = Math.abs(m - 1.0);
      const smile = 0.035 * d * d + (m < 1.0 ? 0.012 * d : 0);
      return mktAvgIV(dte) + smile;
    })
  );
  return { grid, mRange, dteRange };
}

// ─── Main loader ──────────────────────────────────────────────────────────────
async function loadOptionsData(ticker, contractType = 'both', onProgress = () => {}) {
  onProgress('Fetching quote…', 5);
  const quote = await apiFetch(`/quote?ticker=${ticker}`);

  onProgress('Fetching expirations…', 12);
  const { expirationDates } = await apiFetch(`/expirations?ticker=${ticker}`);
  const expSlice = expirationDates.slice(0, 12);

  let allContracts = [];
  const expInfo    = [];

  for (let i = 0; i < expSlice.length; i++) {
    const ts = expSlice[i];
    onProgress(
      `Chain ${i + 1} / ${expSlice.length}  ·  ${fmtDate(ts)}`,
      12 + (i / expSlice.length) * 78
    );

    try {
      const { calls, puts } = await apiFetch(`/chain?ticker=${ticker}&exp=${ts}`);
      const contracts = processContracts(calls, puts, contractType, quote.price, ts);
      contracts.forEach(c => c.ticker = ticker.toUpperCase());
      allContracts = allContracts.concat(contracts);

      const atmC  = contracts.filter(c => Math.abs(c.moneyness - 1) < 0.025);
      const atmIV = atmC.length ? atmC.reduce((s, c) => s + c.iv, 0) / atmC.length : null;

      expInfo.push({ ts, date: fmtDate(ts), dte: calcDTE(ts), atmIV, nContracts: contracts.length });
    } catch (e) {
      console.warn('Skipped expiry', fmtDate(ts), '—', e.message);
    }
  }

  if (!allContracts.length) {
    throw new Error('No valid options returned. The ticker may not have listed options.');
  }

  const ivs     = allContracts.map(c => c.iv);
  const avgIV   = ivs.reduce((a, b) => a + b, 0) / ivs.length;
  const atm30   = allContracts.filter(c => Math.abs(c.moneyness - 1) < 0.025 && c.dte >= 25 && c.dte <= 35);
  const atmIV30 = atm30.length ? atm30.reduce((s, c) => s + c.iv, 0) / atm30.length : avgIV;

  const puts5  = allContracts.filter(c => c.type === 'put'  && c.moneyness >= 0.93 && c.moneyness <= 0.97 && c.dte >= 25 && c.dte <= 35);
  const calls5 = allContracts.filter(c => c.type === 'call' && c.moneyness >= 1.03 && c.moneyness <= 1.07 && c.dte >= 25 && c.dte <= 35);
  const putIV  = puts5.length  ? puts5.reduce((s, c)  => s + c.iv, 0) / puts5.length  : null;
  const callIV = calls5.length ? calls5.reduce((s, c) => s + c.iv, 0) / calls5.length : null;
  const skew   = putIV && callIV ? putIV - callIV : null;
  const ivPct  = Math.min(Math.round(((atmIV30 / mktAvgIV(30)) - 0.5) * 100), 99);

  onProgress('Building IV surface mesh…', 95);
  const surface = buildIVSurface(allContracts);

  return {
    ticker: ticker.toUpperCase(),
    quote,
    contracts: allContracts,
    expirations: expInfo,
    surface,
    stats: {
      n: allContracts.length,
      nExp: expInfo.length,
      avgIV, atmIV30, skew, ivPct,
      em30: expMove(quote.price, atmIV30, 30),
      mktAvgIV30: mktAvgIV(30),
    },
    timestamp: new Date(),
  };
}
