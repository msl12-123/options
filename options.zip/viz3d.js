/**
 * viz3d.js — Implied Volatility Surface Renderer
 *
 * Renders a true continuous parametric surface mesh from interpolated IV data.
 * Supports overlay scatter points, hover picking, and real-time surface updates.
 */

'use strict';

class IVSurfaceRenderer {
  constructor(canvasId) {
    this.canvas     = document.getElementById(canvasId);
    this.tooltip    = document.getElementById('tooltip');
    this.contracts  = [];
    this.spheres    = [];
    this.surfaceMesh = null;
    this.avgMesh    = null;
    this.colorMode  = 'iv';
    this.viewMode   = 'surface';
    this.hoveredObj = null;
    this.raycaster  = new THREE.Raycaster();
    this.mouse      = new THREE.Vector2(-9999, -9999);
    this._hoveredSurface = null;

    this._init();
  }

  // ─── Initialise ──────────────────────────────────────────────────────────────
  _init() {
    const W = this.canvas.parentElement.clientWidth  || 800;
    const H = this.canvas.parentElement.clientHeight || 600;

    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x0a0c0f);
    this.scene.fog = new THREE.FogExp2(0x0a0c0f, 0.018);

    // Camera
    this.camera = new THREE.PerspectiveCamera(48, W / H, 0.1, 500);
    this.camera.position.set(18, 14, 26);
    this.camera.lookAt(0, 4, 0);

    // Renderer
    this.renderer = new THREE.WebGLRenderer({ canvas: this.canvas, antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(W, H);
    this.renderer.toneMapping = THREE.ReinhardToneMapping;
    this.renderer.toneMappingExposure = 1.1;

    // Controls
    this.controls = new THREE.OrbitControls(this.camera, this.canvas);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.06;
    this.controls.rotateSpeed   = 0.5;
    this.controls.zoomSpeed     = 0.7;
    this.controls.minDistance   = 4;
    this.controls.maxDistance   = 100;
    this.controls.target.set(0, 4, 0);

    // Lighting — subtle, professional
    this.scene.add(new THREE.AmbientLight(0x08111e, 4));
    const d1 = new THREE.DirectionalLight(0xc8c0b0, 1.6); d1.position.set(10, 20, 10); this.scene.add(d1);
    const d2 = new THREE.DirectionalLight(0x1a2840, 0.8); d2.position.set(-10, 5, -8); this.scene.add(d2);
    const d3 = new THREE.DirectionalLight(0xc8a84b, 0.4); d3.position.set(0, -10, 0);  this.scene.add(d3);

    this._buildBaseScene();

    window.addEventListener('resize', () => this._resize());
    this.canvas.addEventListener('mousemove', e => this._onMouseMove(e));
    this.canvas.addEventListener('mouseleave', () => this._hideTooltip());

    this._animate();
  }

  _buildBaseScene() {
    // Grid floor
    const g = new THREE.GridHelper(36, 36, 0x111820, 0x0d1420);
    g.position.y = -0.1;
    this.scene.add(g);

    // Axis lines
    const line = (p1, p2, c, op = 0.35) => {
      const geo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(...p1), new THREE.Vector3(...p2)]);
      this.scene.add(new THREE.Line(geo, new THREE.LineBasicMaterial({ color: c, transparent: true, opacity: op })));
    };

    line([-16,0,0], [16,0,0],  0x8a3030, 0.4); // X moneyness — red
    line([0,0,0],   [0,24,0],  0x2a6a30, 0.4); // Y IV — green
    line([0,0,-14], [0,0,14],  0x203060, 0.4); // Z DTE — blue

    // ATM plane marker
    const atmGeo = new THREE.PlaneGeometry(0.01, 24);
    const atmMat = new THREE.MeshBasicMaterial({ color: 0xc8a84b, transparent: true, opacity: 0.05, side: THREE.DoubleSide });
    const atm = new THREE.Mesh(atmGeo, atmMat);
    atm.rotation.y = Math.PI / 2;
    atm.position.set(0, 12, 0);
    this.scene.add(atm);

    // ATM vertical guide
    line([0,0,-14], [0,0,14], 0xc8a84b, 0.2);
  }

  // ─── Coordinate mapping ───────────────────────────────────────────────────────
  // X: moneyness 0.7–1.3   →  -13 to +13
  // Y: IV 0–120%           →   0  to 22
  // Z: DTE 0–365           →  -12 to +12
  _x(m)   { return (m - 1.0) * 22; }
  _y(iv)  { return Math.min(iv * 20, 22); }
  _z(dte) { return ((dte / 365) * 2 - 1) * 12; }

  // ─── Color mapping ────────────────────────────────────────────────────────────
  _ivColor(iv, minIV, maxIV, mode, contract = null) {
    let t = 0;
    if (mode === 'iv') {
      t = Math.max(0, Math.min(1, (iv - minIV) / Math.max(maxIV - minIV, 0.01)));
    } else if (mode === 'iv_vs_avg' && contract) {
      t = Math.max(0, Math.min(1, (contract.ivVsAvg + 0.5) / 1.0));
    } else if (mode === 'skew' && contract) {
      // Put wing vs call wing skew visualization
      t = contract.moneyness < 1.0
        ? Math.max(0, Math.min(1, (1.0 - contract.moneyness) * 3))
        : Math.max(0, Math.min(1, (contract.moneyness - 1.0) * 2));
    } else {
      t = Math.max(0, Math.min(1, (iv - minIV) / Math.max(maxIV - minIV, 0.01)));
    }
    return this._paletteSurface(t);
  }

  // Goldman-appropriate palette: deep blue → teal → gold → red
  _paletteSurface(t) {
    const stops = [
      [0.00, [20,  45,  80]],   // deep navy
      [0.25, [25,  90,  120]],  // steel blue
      [0.50, [30,  120, 90]],   // teal
      [0.70, [160, 140, 50]],   // gold
      [0.85, [180, 80,  30]],   // amber-red
      [1.00, [160, 30,  30]],   // deep red
    ];

    for (let i = 0; i < stops.length - 1; i++) {
      const [t0, c0] = stops[i];
      const [t1, c1] = stops[i + 1];
      if (t >= t0 && t <= t1) {
        const f = (t - t0) / (t1 - t0);
        return new THREE.Color(
          (c0[0] + (c1[0] - c0[0]) * f) / 255,
          (c0[1] + (c1[1] - c0[1]) * f) / 255,
          (c0[2] + (c1[2] - c0[2]) * f) / 255
        );
      }
    }
    return new THREE.Color(0.8, 0.2, 0.2);
  }

  // ─── Build continuous IV surface mesh ────────────────────────────────────────
  buildSurface(surfaceData, colorMode = 'iv') {
    // Remove old
    if (this.surfaceMesh) { this.scene.remove(this.surfaceMesh); this.surfaceMesh.geometry.dispose(); }
    if (this._wireMesh)   { this.scene.remove(this._wireMesh);   this._wireMesh.geometry.dispose(); }

    const { grid, mRange, dteRange } = surfaceData;
    if (!grid || dteRange.length < 2 || mRange.length < 2) return;

    this.colorMode = colorMode;
    this._surfaceData = surfaceData;

    const rows = dteRange.length;
    const cols = mRange.length;

    // Flatten IV grid for color range
    const allIVs = grid.flat().filter(v => v !== null);
    const minIV  = Math.min(...allIVs);
    const maxIV  = Math.max(...allIVs);

    // Build vertex positions and colors
    const positions = [];
    const colors    = [];
    const uvs       = [];

    for (let ri = 0; ri < rows; ri++) {
      for (let ci = 0; ci < cols; ci++) {
        const iv  = grid[ri][ci] ?? minIV;
        const m   = mRange[ci];
        const dte = dteRange[ri];

        positions.push(this._x(m), this._y(iv), this._z(dte));

        const col = this._paletteSurface((iv - minIV) / Math.max(maxIV - minIV, 0.01));
        colors.push(col.r, col.g, col.b);
        uvs.push(ci / (cols - 1), ri / (rows - 1));
      }
    }

    // Build triangle index buffer
    const indices = [];
    for (let ri = 0; ri < rows - 1; ri++) {
      for (let ci = 0; ci < cols - 1; ci++) {
        const a = ri * cols + ci;
        const b = a + 1;
        const c = (ri + 1) * cols + ci;
        const d = c + 1;
        indices.push(a, c, b, b, c, d);
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute('color',    new THREE.Float32BufferAttribute(colors, 3));
    geo.setAttribute('uv',       new THREE.Float32BufferAttribute(uvs, 2));
    geo.setIndex(indices);
    geo.computeVertexNormals();

    const mat = new THREE.MeshPhongMaterial({
      vertexColors: true,
      side:         THREE.DoubleSide,
      transparent:  false,
      shininess:    40,
      specular:     new THREE.Color(0.06, 0.08, 0.12),
    });

    this.surfaceMesh = new THREE.Mesh(geo, mat);
    this.surfaceMesh.userData.isSurface = true;
    this.surfaceMesh.userData.grid      = grid;
    this.surfaceMesh.userData.mRange    = mRange;
    this.surfaceMesh.userData.dteRange  = dteRange;
    this.surfaceMesh.userData.minIV     = minIV;
    this.surfaceMesh.userData.maxIV     = maxIV;
    this.scene.add(this.surfaceMesh);

    // Wireframe overlay — very faint
    const wireGeo = geo.clone();
    const wireMat = new THREE.MeshBasicMaterial({
      color: 0x1c2535, wireframe: true, transparent: true, opacity: 0.25
    });
    this._wireMesh = new THREE.Mesh(wireGeo, wireMat);
    this.scene.add(this._wireMesh);

    // Update legend
    this._updateLegend(minIV, maxIV);

    return { minIV, maxIV };
  }

  // ─── Market average reference surface ─────────────────────────────────────────
  buildAvgSurface(surfaceData) {
    if (this.avgMesh) { this.scene.remove(this.avgMesh); this.avgMesh.geometry.dispose(); }

    const { grid, mRange, dteRange } = surfaceData;
    const rows = dteRange.length;
    const cols = mRange.length;

    const positions = [];
    for (let ri = 0; ri < rows; ri++) {
      for (let ci = 0; ci < cols; ci++) {
        const iv = grid[ri][ci] ?? 0.18;
        positions.push(this._x(mRange[ci]), this._y(iv), this._z(dteRange[ri]));
      }
    }

    const indices = [];
    for (let ri = 0; ri < rows - 1; ri++) {
      for (let ci = 0; ci < cols - 1; ci++) {
        const a = ri * cols + ci, b = a + 1, c = (ri + 1) * cols + ci, d = c + 1;
        indices.push(a, c, b, b, c, d);
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setIndex(indices);
    geo.computeVertexNormals();

    const mat = new THREE.MeshBasicMaterial({
      color: 0x1a2840, wireframe: true, transparent: true, opacity: 0.3
    });
    this.avgMesh = new THREE.Mesh(geo, mat);
    this.scene.add(this.avgMesh);
  }

  // ─── Scatter point overlay ────────────────────────────────────────────────────
  buildPoints(contracts, colorMode = 'iv') {
    // Remove existing
    for (const s of this.spheres) { this.scene.remove(s); s.geometry.dispose(); s.material.dispose(); }
    this.spheres = [];

    if (!contracts.length) return;

    const ivs = contracts.map(c => c.iv);
    const minIV = Math.min(...ivs), maxIV = Math.max(...ivs);

    const geo = new THREE.SphereGeometry(0.13, 8, 8);

    for (const c of contracts) {
      const col = this._paletteSurface((c.iv - minIV) / Math.max(maxIV - minIV, 0.01));
      const mat = new THREE.MeshPhongMaterial({
        color: col, emissive: col, emissiveIntensity: 0.2,
        transparent: true, opacity: c.type === 'call' ? 0.9 : 0.75, shininess: 60
      });
      const s = new THREE.Mesh(geo, mat);
      s.position.set(this._x(c.moneyness), this._y(c.iv), this._z(c.dte));
      s.userData.contract  = c;
      s.userData.baseScale = Math.min(1 + Math.log10(Math.max(c.oi, 1) + 1) * 0.1, 2);
      s.scale.setScalar(s.userData.baseScale);
      this.scene.add(s);
      this.spheres.push(s);
    }
  }

  // ─── Legend ───────────────────────────────────────────────────────────────────
  _updateLegend(minIV, maxIV) {
    const lo  = document.getElementById('leg-lo');
    const mid = document.getElementById('leg-mid');
    const hi  = document.getElementById('leg-hi');
    if (lo)  lo.textContent  = (minIV * 100).toFixed(0) + '%';
    if (mid) mid.textContent = ((minIV + maxIV) / 2 * 100).toFixed(0) + '%';
    if (hi)  hi.textContent  = (maxIV * 100).toFixed(0) + '%';
  }

  // ─── Toggle visibility ────────────────────────────────────────────────────────
  setViewMode(mode) {
    this.viewMode = mode;
    const showSurface = mode === 'surface' || mode === 'both';
    const showPoints  = mode === 'points'  || mode === 'both';
    if (this.surfaceMesh) this.surfaceMesh.visible = showSurface;
    if (this._wireMesh)   this._wireMesh.visible   = showSurface;
    for (const s of this.spheres) s.visible = showPoints;
  }

  // ─── Mouse interaction ────────────────────────────────────────────────────────
  _onMouseMove(e) {
    const rect = this.canvas.getBoundingClientRect();
    this.mouse.x =  ((e.clientX - rect.left) / rect.width)  * 2 - 1;
    this.mouse.y = -((e.clientY - rect.top)  / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);

    // Check spheres first (higher priority)
    if (this.spheres.length && (this.viewMode === 'points' || this.viewMode === 'both')) {
      const hits = this.raycaster.intersectObjects(this.spheres);
      if (hits.length) {
        const obj = hits[0].object;
        if (obj !== this.hoveredObj) {
          if (this.hoveredObj) this._unhover(this.hoveredObj);
          this.hoveredObj = obj;
          this._hover(obj);
        }
        this._showContractTooltip(e, obj.userData.contract);
        return;
      }
    }

    // Check surface mesh
    if (this.surfaceMesh && (this.viewMode === 'surface' || this.viewMode === 'both')) {
      const hits = this.raycaster.intersectObject(this.surfaceMesh);
      if (hits.length) {
        if (this.hoveredObj) { this._unhover(this.hoveredObj); this.hoveredObj = null; }
        this._showSurfaceTooltip(e, hits[0].point);
        return;
      }
    }

    if (this.hoveredObj) { this._unhover(this.hoveredObj); this.hoveredObj = null; }
    this._hideTooltip();
  }

  _hover(obj) {
    obj.material.emissiveIntensity = 0.9;
    obj.scale.setScalar(obj.userData.baseScale * 1.6);
  }

  _unhover(obj) {
    obj.material.emissiveIntensity = 0.2;
    obj.scale.setScalar(obj.userData.baseScale);
  }

  _showContractTooltip(e, c) {
    const pct = v => (v * 100).toFixed(2) + '%';
    const d   = c.ivVsAvg * 100;

    document.getElementById('tt-sym').textContent = `${c.ticker} · ${c.type.toUpperCase()} $${c.strike} · ${c.expDate}`;

    const rows = [
      ['Strike',       `$${c.strike.toFixed(2)}`],
      ['DTE',          `${c.dte} days`],
      ['Impl. Vol',    pct(c.iv)],
      ['Mkt Avg IV',   pct(c.marketAvgIV)],
      ['IV vs Avg',    `${d >= 0 ? '+' : ''}${d.toFixed(1)}%`, d > 5 ? 'red' : d < -5 ? 'green' : ''],
      ['Exp. Move',    `±$${c.em.toFixed(2)} (${pct(c.emPct)})`],
      ['Volume',       c.volume.toLocaleString()],
      ['Open Int.',    c.oi.toLocaleString()],
      ['Bid / Ask',    `${c.bid.toFixed(2)} / ${c.ask.toFixed(2)}`],
      ['Last',         `$${c.last.toFixed(2)}`],
    ];

    document.getElementById('tt-rows').innerHTML = rows.map(([l, v, cls = '']) =>
      `<span class="tt-l">${l}</span><span class="tt-v ${cls}">${v}</span>`
    ).join('');

    this._positionTooltip(e);
    document.getElementById('tooltip').classList.remove('hidden');

    // Update right panel selected contract
    this._updateSelectedPanel(c);
  }

  _showSurfaceTooltip(e, point) {
    // Reverse-map 3D point back to IV surface coordinates
    const m   = point.x / 22 + 1.0;
    const iv  = point.y / 20;
    const dte = Math.round((point.z / 12 + 1) / 2 * 365);

    document.getElementById('tt-sym').textContent = `SURFACE · ${(m * 100).toFixed(0)}% moneyness · ${dte}d DTE`;

    const rows = [
      ['Moneyness',  (m * 100).toFixed(1) + '%'],
      ['Impl. Vol',  (iv * 100).toFixed(1) + '%'],
      ['DTE',        dte + ' days'],
      ['Mkt Avg IV', (mktAvgIV(dte) * 100).toFixed(1) + '%'],
      ['IV vs Avg',  ((iv - mktAvgIV(dte)) / mktAvgIV(dte) * 100).toFixed(1) + '%'],
    ];

    document.getElementById('tt-rows').innerHTML = rows.map(([l, v]) =>
      `<span class="tt-l">${l}</span><span class="tt-v">${v}</span>`
    ).join('');

    this._positionTooltip(e);
    document.getElementById('tooltip').classList.remove('hidden');
  }

  _hideTooltip() { document.getElementById('tooltip').classList.add('hidden'); }

  _positionTooltip(e) {
    const rect = this.canvas.getBoundingClientRect();
    const tt   = document.getElementById('tooltip');
    let x = e.clientX - rect.left + 16;
    let y = e.clientY - rect.top  - 80;
    if (x + 240 > rect.width)  x = e.clientX - rect.left - 256;
    if (y < 0) y = 8;
    tt.style.left = x + 'px';
    tt.style.top  = y + 'px';
  }

  _updateSelectedPanel(c) {
    const panel = document.getElementById('chain-body');
    if (!panel) return;
    const pct = v => (v * 100).toFixed(2) + '%';
    const d   = c.ivVsAvg * 100;
    panel.innerHTML = `
      <div class="contract-detail">
        <div class="cd-item"><div class="cd-l">Symbol</div><div class="cd-v" style="font-size:9px;word-break:break-all">${c.symbol || '—'}</div></div>
        <div class="cd-item"><div class="cd-l">Type</div><div class="cd-v" style="color:${c.type==='call'?'#2a9d6f':'#c0392b'}">${c.type.toUpperCase()}</div></div>
        <div class="cd-item"><div class="cd-l">Strike</div><div class="cd-v">$${c.strike.toFixed(2)}</div></div>
        <div class="cd-item"><div class="cd-l">DTE</div><div class="cd-v">${c.dte}d</div></div>
        <div class="cd-item"><div class="cd-l">IV</div><div class="cd-v" style="color:var(--gold)">${pct(c.iv)}</div></div>
        <div class="cd-item"><div class="cd-l">vs Avg</div><div class="cd-v" style="color:${d>0?'#c0392b':'#2a9d6f'}">${d>=0?'+':''}${d.toFixed(1)}%</div></div>
        <div class="cd-item"><div class="cd-l">Bid</div><div class="cd-v">$${c.bid.toFixed(2)}</div></div>
        <div class="cd-item"><div class="cd-l">Ask</div><div class="cd-v">$${c.ask.toFixed(2)}</div></div>
        <div class="cd-item"><div class="cd-l">Volume</div><div class="cd-v">${c.volume.toLocaleString()}</div></div>
        <div class="cd-item"><div class="cd-l">OI</div><div class="cd-v">${c.oi.toLocaleString()}</div></div>
        <div class="cd-item"><div class="cd-l">Exp. Move</div><div class="cd-v">±$${c.em.toFixed(2)}</div></div>
        <div class="cd-item"><div class="cd-l">Exp. Move%</div><div class="cd-v">±${pct(c.emPct)}</div></div>
      </div>
    `;
  }

  // ─── Resize ───────────────────────────────────────────────────────────────────
  _resize() {
    const c = this.canvas.parentElement;
    this.camera.aspect = c.clientWidth / c.clientHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(c.clientWidth, c.clientHeight);
  }

  // ─── Animate ──────────────────────────────────────────────────────────────────
  _animate() {
    requestAnimationFrame(() => this._animate());
    this.controls.update();
    const t = Date.now() * 0.0008;
    for (const s of this.spheres) {
      if (s !== this.hoveredObj) {
        const b = s.userData.baseScale;
        s.scale.setScalar(b * (1 + Math.sin(t + s.position.x * 0.6) * 0.03));
      }
    }
    this.renderer.render(this.scene, this.camera);
  }

  resetCamera() {
    this.camera.position.set(18, 14, 26);
    this.controls.target.set(0, 4, 0);
    this.controls.update();
  }

  clear() {
    if (this.surfaceMesh) { this.scene.remove(this.surfaceMesh); this.surfaceMesh.geometry.dispose(); this.surfaceMesh = null; }
    if (this._wireMesh)   { this.scene.remove(this._wireMesh);   this._wireMesh.geometry.dispose();   this._wireMesh   = null; }
    if (this.avgMesh)     { this.scene.remove(this.avgMesh);     this.avgMesh.geometry.dispose();     this.avgMesh     = null; }
    for (const s of this.spheres) { this.scene.remove(s); s.geometry.dispose(); s.material.dispose(); }
    this.spheres = [];
    this.contracts = [];
  }
}
