#!/bin/bash
# ─── IV Surface — Quick Start ─────────────────────────────────────────────────
# Run this script from the project folder to launch the app.

echo ""
echo "  IV Surface — Derivatives Analytics"
echo "  ─────────────────────────────────────"

# Check Node.js is installed
if ! command -v node &> /dev/null; then
  echo ""
  echo "  ERROR: Node.js is not installed."
  echo ""
  echo "  Install it from https://nodejs.org  (LTS version recommended)"
  echo ""
  exit 1
fi

NODE_VERSION=$(node -e "process.stdout.write(process.version)")
echo "  Node.js $NODE_VERSION detected"
echo ""

# Start server
node server.js &
SERVER_PID=$!

# Give it a moment to start
sleep 1

# Try to open the browser automatically
URL="http://localhost:3000"
if command -v open &> /dev/null; then
  open "$URL"
elif command -v xdg-open &> /dev/null; then
  xdg-open "$URL"
elif command -v start &> /dev/null; then
  start "$URL"
fi

echo "  Open this URL in your browser → $URL"
echo ""
echo "  Press Ctrl+C to stop the server."
echo ""

# Wait for server process
wait $SERVER_PID
