/**
 * app.js — Application Controller
 * Goldman Sachs-grade derivatives analytics terminal
 */

'use strict';

// ─── State ────────────────────────────────────────────────────────────────────
const S = {
  ticker:       null,
  data:         null,
  contractType: 'both',
  viewMode:     'surface',
  colorMode:    'iv',
  maxDTE:       365,
  strikeWidth:  80, // percentage points from ATM (e.g. 80 = 80–120%)
};

let renderer;
let barTimer;

// ─── Boot ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  renderer = new IVSurfaceRenderer('main-canvas');
  startClock();
  bindEvents();
  setStatus('IDLE', 'idle');
});

// ─── Clock ────────────────────────────────────────────────────────────────────
function startClock() {
  const tick = () => {
    const now = new Date();
    const tz  = Intl.DateTimeFormat().resolvedOptions().timeZone;
    document.getElementById('tb-time').textContent =
      now.toLocaleTimeString('en-US', { hour12: false }) + '  ' + tz.replace('_', ' ');
  };
  tick();
  setInterval(tick, 1000);
}

// ─── Events ───────────────────────────────────────────────────────────────────
function bindEvents() {
  // Load
  document.getElementById('load-btn').addEventListener('click', () => {
    const t = document.getElementById('ticker-input').value.trim().toUpperCase();
    if (t) loadTicker(t);
  });

  document.getElementById('ticker-input').addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      const t = e.target.value.trim().toUpperCase();
      if (t) loadTicker(t);
    }
  });

  // Quick tickers
  document.querySelectorAll('.q-btn').forEach(b => b.addEventListener('click', () => loadTicker(b.dataset.t)));

  // Contract type
  document.querySelectorAll('[data-type]').forEach(b => b.addEventListener('click', () => {
    seg('#type-seg', b); S.contractType = b.dataset.type;
    if (S.data) rebuildViz();
  }));

  // View mode
  document.querySelectorAll('[data-view]').forEach(b => b.addEventListener('click', () => {
    seg('#view-seg', b); S.viewMode = b.dataset.view;
    if (renderer) renderer.setViewMode(S.viewMode);
  }));

  // Color mode
  document.querySelectorAll('[data-color]').forEach(b => b.addEventListener('click', () => {
    seg('#color-seg', b); S.colorMode = b.dataset.color;
    if (S.data) rebuildViz();
  }));

  // DTE slider
  const dteSlider = document.getElementById('dte-range');
  const dteDisplay = document.getElementById('dte-val');
  dteSlider.addEventListener('input', () => {
    S.maxDTE = parseInt(dteSlider.value);
    dteDisplay.textContent = S.maxDTE >= 365 ? 'ALL' : S.maxDTE + 'D';
    if (S.data) rebuildViz();
  });

  // Strike width slider
  const strikeSlider = document.getElementById('strike-range');
  const strikeDisplay = document.getElementById('strike-val');
  strikeSlider.addEventListener('input', () => {
    S.strikeWidth = parseInt(strikeSlider.value);
    const lo = (100 - S.strikeWidth).toFixed(0);
    const hi = (100 + S.strikeWidth).toFixed(0);
    strikeDisplay.textContent = `${lo}–${hi}%`;
    if (S.data) rebuildViz();
  });
}

function seg(containerSelector, activeBtn) {
  document.querySelectorAll(containerSelector + ' .seg').forEach(b => b.classList.remove('active'));
  activeBtn.classList.add('active');
}

// ─── Load ─────────────────────────────────────────────────────────────────────
async function loadTicker(ticker) {
  if (!ticker) return;
  S.ticker = ticker;
  document.getElementById('ticker-input').value = ticker;

  setStatus('LOADING', 'loading');
  showLoading(true);
  renderer.clear();

  // Animate progress
  let pct = 0;
  clearInterval(barTimer);
  barTimer = setInterval(() => {
    pct = Math.min(pct + 2, 88);
    setBar(pct);
  }, 150);

  try {
    const data = await loadOptionsData(ticker, S.contractType, (msg, p) => {
      document.getElementById('ld-sub').textContent = msg;
      if (p) setBar(p);
    });

    S.data = data;
    clearInterval(barTimer);
    setBar(100);

    await delay(150);
    showLoading(false);

    buildViz(data);
    populateQuotePanel(data.quote);
    populateStatsPanel(data.stats, data.quote);
    populateExpPanel(data.expirations);
    populateComparePanel(data.stats);
    populateQuoteStrip(data.quote);
    updateStatusBar(data.stats, data.quote, data.timestamp);
    drawSkewChart(data.contracts);
    drawTermChart(data.expirations);

    renderer.resetCamera();
    setStatus(ticker + ' · ' + data.stats.n.toLocaleString() + ' CONTRACTS', 'ok');

  } catch (err) {
    console.error(err);
    clearInterval(barTimer);
    setBar(0);
    showLoading(false);
    document.getElementById('empty-state').style.display = 'block';
    document.getElementById('empty-state').querySelector('.es-label').textContent = 'LOAD FAILED — ' + err.message.substring(0, 60);
    setStatus('ERROR', 'error');
  }
}

// ─── Viz build ────────────────────────────────────────────────────────────────
function buildViz(data) {
  if (!data.surface) return;

  // Filter contracts
  const filtered = filterContracts(data.contracts);

  // Build market avg reference
  const avgSurface = buildMarketAvgSurface();
  renderer.buildAvgSurface(avgSurface);

  // Build main IV surface using all data for smoothness
  renderer.buildSurface(data.surface, S.colorMode);

  // Overlay points if needed
  if (S.viewMode !== 'surface') {
    renderer.buildPoints(filtered, S.colorMode);
  }

  renderer.setViewMode(S.viewMode);
}

function rebuildViz() {
  if (!S.data) return;
  renderer.clear();
  buildViz(S.data);
}

function filterContracts(contracts) {
  let c = contracts;

  if (S.contractType !== 'both') {
    const t = S.contractType === 'calls' ? 'call' : 'put';
    c = c.filter(x => x.type === t);
  }

  if (S.maxDTE < 365) {
    c = c.filter(x => x.dte <= S.maxDTE);
  }

  const loMn = (100 - S.strikeWidth) / 100;
  const hiMn = (100 + S.strikeWidth) / 100;
  c = c.filter(x => x.moneyness >= loMn && x.moneyness <= hiMn);

  return c;
}

// ─── Panel updates ────────────────────────────────────────────────────────────
function populateQuoteStrip(q) {
  const isUp = q.change >= 0;
  document.getElementById('tb-quote-strip').innerHTML = `
    <span class="qs-ticker">${q.ticker}</span>
    <span class="qs-price">$${n2(q.price)}</span>
    <span class="qs-change ${isUp ? 'up' : 'down'}">${isUp ? '▲' : '▼'} ${n2(Math.abs(q.change))} (${n2(Math.abs(q.changePct))}%)</span>
  `;
}

function populateQuotePanel(q) {
  const isUp = q.change >= 0;
  document.getElementById('quote-body').innerHTML = `
    <div class="q-ticker">${q.ticker}</div>
    <div class="q-name">${q.name}</div>
    <div class="q-price">$${n2(q.price)}</div>
    <div class="q-chg ${isUp ? 'up' : 'down'}">${isUp ? '▲' : '▼'} ${n2(Math.abs(q.change))} &nbsp; ${n2(Math.abs(q.changePct))}%</div>
    <div class="q-grid">
      <div class="q-cell"><div class="ql">Exchange</div><div class="qv">${q.exchange}</div></div>
      <div class="q-cell"><div class="ql">Currency</div><div class="qv">${q.currency}</div></div>
      ${q.mktCap ? `<div class="q-cell"><div class="ql">Mkt Cap</div><div class="qv">${fmtCap(q.mktCap)}</div></div>` : ''}
      ${q.volume ? `<div class="q-cell"><div class="ql">Volume</div><div class="qv">${fmtVol(q.volume)}</div></div>` : ''}
      ${q.high52 ? `<div class="q-cell"><div class="ql">52W High</div><div class="qv">$${n2(q.high52)}</div></div>` : ''}
      ${q.low52  ? `<div class="q-cell"><div class="ql">52W Low</div><div class="qv">$${n2(q.low52)}</div></div>` : ''}
    </div>
  `;
}

function populateStatsPanel(stats, quote) {
  const rows = [
    ['ATM IV (30D)',    (stats.atmIV30 * 100).toFixed(2) + '%',  'gold'],
    ['Avg IV (all)',    (stats.avgIV   * 100).toFixed(2) + '%',  ''],
    ['Mkt Avg IV (30D)', (stats.mktAvgIV30 * 100).toFixed(2) + '%', ''],
    ['30D Exp. Move',  '±$' + n2(stats.em30) + ' (±' + n2(stats.em30 / quote.price * 100) + '%)', ''],
    ['Put/Call Skew',  stats.skew != null ? (stats.skew > 0 ? '+' : '') + (stats.skew * 100).toFixed(2) + '%' : 'N/A',
      stats.skew > 0.03 ? 'red' : stats.skew < -0.02 ? 'green' : ''],
    ['IV Percentile',  stats.ivPct + '%ile', stats.ivPct > 70 ? 'red' : stats.ivPct < 30 ? 'green' : 'gold'],
    ['Total Contracts', stats.n.toLocaleString(), ''],
    ['Expirations',    stats.nExp, ''],
  ];

  document.getElementById('stats-body').innerHTML = rows.map(([l, v, cls]) =>
    `<div class="stat-row"><span class="stat-lbl">${l}</span><span class="stat-val ${cls}">${v}</span></div>`
  ).join('');
}

function populateExpPanel(expirations) {
  document.getElementById('exp-body').innerHTML = `
    <div class="exp-hdr-row"><span>DATE</span><span>DTE</span><span>ATM IV</span></div>
    ${expirations.map(e => `
      <div class="exp-row">
        <span class="exp-date">${e.date}</span>
        <span class="exp-dte">${e.dte}</span>
        <span class="exp-iv">${e.atmIV != null ? (e.atmIV * 100).toFixed(1) + '%' : '—'}</span>
      </div>
    `).join('')}
  `;
}

function populateComparePanel(stats) {
  const mkt = stats.mktAvgIV30;

  const row = (lbl, val, avg) => {
    const ratio = avg > 0 ? val / avg : 1;
    const width = Math.min(ratio * 50, 100).toFixed(1);
    const diff  = ((ratio - 1) * 100).toFixed(1);
    const cls   = ratio > 1 ? 'above' : ratio < 0.9 ? 'below' : 'neutral';
    return `
      <div class="cmp-item">
        <div class="cmp-top"><span class="cmp-lbl">${lbl}</span><span class="cmp-val">${(val*100).toFixed(2)}%</span></div>
        <div class="cmp-track"><div class="cmp-fill" style="width:${width}%"></div></div>
        <div class="cmp-diff ${cls}">${diff > 0 ? '+' : ''}${diff}% vs market baseline</div>
      </div>
    `;
  };

  const skewColor = stats.skew > 0.04 ? 'var(--red)' : stats.skew < -0.02 ? 'var(--green)' : 'var(--gold)';
  const skewDesc  = stats.skew > 0.04 ? 'Elevated put skew — downside hedging demand'
                  : stats.skew < -0.02 ? 'Call skew — upside demand elevated'
                  : 'Balanced skew';

  document.getElementById('compare-body').innerHTML = `
    ${row('ATM IV (30D)', stats.atmIV30, mkt)}
    ${row('Avg IV (surface)', stats.avgIV, mkt)}
    <div class="skew-inset">
      <div style="font-size:8px;letter-spacing:1px;color:var(--t2);margin-bottom:4px">PUT/CALL IV SKEW</div>
      <div class="skew-big" style="color:${skewColor}">
        ${stats.skew != null ? (stats.skew > 0 ? '+' : '') + (stats.skew * 100).toFixed(2) + '%' : 'N/A'}
      </div>
      <div class="skew-desc">${skewDesc}</div>
    </div>
  `;
}

function updateStatusBar(stats, quote, ts) {
  setT('sb-contracts', stats.n.toLocaleString());
  setT('sb-exps',      stats.nExp);
  setT('sb-atm',       (stats.atmIV30 * 100).toFixed(2) + '%');
  setT('sb-avg',       (stats.avgIV   * 100).toFixed(2) + '%');
  setT('sb-em',        '±$' + n2(stats.em30));
  setT('sb-skew',      stats.skew != null ? (stats.skew > 0 ? '+' : '') + (stats.skew * 100).toFixed(2) + '%' : 'N/A');
  setT('sb-ivp',       stats.ivPct + '%ile');

  const vsEl  = document.getElementById('sb-vsmkt');
  const ratio = stats.atmIV30 / stats.mktAvgIV30;
  vsEl.textContent = ratio.toFixed(2) + 'x';
  vsEl.style.color = ratio > 1.4 ? 'var(--red)' : ratio > 1.15 ? 'var(--gold)' : 'var(--green)';

  setT('sb-updated', ts.toLocaleTimeString('en-US', { hour12: false }));
}

// ─── Sparkline charts ─────────────────────────────────────────────────────────
function drawTermChart(expirations) {
  const canvas = document.getElementById('term-chart');
  const ctx    = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  const p = { t: 8, r: 8, b: 20, l: 30 };

  ctx.clearRect(0, 0, W, H);

  const valid = expirations.filter(e => e.atmIV != null && e.dte > 0);
  if (valid.length < 2) return;

  const maxD = Math.max(...valid.map(e => e.dte));
  const ivs  = valid.map(e => e.atmIV);
  const maxIV = Math.max(...ivs) * 1.1;
  const minIV = Math.max(0, Math.min(...ivs) * 0.9);

  const xS = d  => p.l + (d / maxD) * (W - p.l - p.r);
  const yS = iv => H - p.b - ((iv - minIV) / (maxIV - minIV)) * (H - p.t - p.b);

  // Grid lines
  ctx.strokeStyle = '#0d1420'; ctx.lineWidth = 0.5;
  for (let i = 0; i <= 3; i++) {
    const y = p.t + (i / 3) * (H - p.t - p.b);
    ctx.beginPath(); ctx.moveTo(p.l, y); ctx.lineTo(W - p.r, y); ctx.stroke();
    const iv = maxIV - (i / 3) * (maxIV - minIV);
    ctx.fillStyle = '#2a3545'; ctx.font = '8px IBM Plex Mono'; ctx.textAlign = 'right';
    ctx.fillText((iv * 100).toFixed(0) + '%', p.l - 3, y + 3);
  }

  // Mkt avg reference
  const avgY = yS(0.18);
  if (avgY > p.t && avgY < H - p.b) {
    ctx.setLineDash([2, 3]); ctx.strokeStyle = '#8a7030'; ctx.lineWidth = 0.8;
    ctx.beginPath(); ctx.moveTo(p.l, avgY); ctx.lineTo(W - p.r, avgY); ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = '#8a7030'; ctx.font = '7px IBM Plex Mono'; ctx.textAlign = 'left';
    ctx.fillText('AVG', W - p.r - 20, avgY - 2);
  }

  // Area
  const grad = ctx.createLinearGradient(0, p.t, 0, H - p.b);
  grad.addColorStop(0, 'rgba(200,168,75,0.18)');
  grad.addColorStop(1, 'rgba(200,168,75,0.02)');
  ctx.beginPath();
  ctx.moveTo(xS(valid[0].dte), H - p.b);
  valid.forEach(e => ctx.lineTo(xS(e.dte), yS(e.atmIV)));
  ctx.lineTo(xS(valid[valid.length - 1].dte), H - p.b);
  ctx.closePath(); ctx.fillStyle = grad; ctx.fill();

  // Line
  ctx.beginPath(); ctx.strokeStyle = '#c8a84b'; ctx.lineWidth = 1.5; ctx.lineJoin = 'round';
  valid.forEach((e, i) => i ? ctx.lineTo(xS(e.dte), yS(e.atmIV)) : ctx.moveTo(xS(e.dte), yS(e.atmIV)));
  ctx.stroke();

  // Dots + x labels
  ctx.fillStyle = '#c8a84b';
  valid.forEach((e, i) => {
    ctx.beginPath(); ctx.arc(xS(e.dte), yS(e.atmIV), 2, 0, Math.PI * 2); ctx.fill();
    if (i % Math.max(1, Math.floor(valid.length / 4)) === 0) {
      ctx.fillStyle = '#2a3545'; ctx.font = '7px IBM Plex Mono'; ctx.textAlign = 'center';
      ctx.fillText(e.dte + 'd', xS(e.dte), H - p.b + 10);
      ctx.fillStyle = '#c8a84b';
    }
  });
}

function drawSkewChart(contracts) {
  const canvas = document.getElementById('skew-chart');
  const ctx    = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  const p = { t: 8, r: 8, b: 20, l: 30 };

  ctx.clearRect(0, 0, W, H);

  // Use 30d-ish DTE slice
  const slice30 = contracts.filter(c => c.dte >= 20 && c.dte <= 45);
  if (slice30.length < 4) return;

  // Group by moneyness bins
  const bins = {};
  for (const c of slice30) {
    const key = Math.round(c.moneyness * 20) / 20; // round to nearest 0.05
    if (!bins[key]) bins[key] = [];
    bins[key].push(c.iv);
  }

  const pts = Object.entries(bins)
    .map(([m, ivs]) => ({ m: parseFloat(m), iv: ivs.reduce((a, b) => a + b) / ivs.length }))
    .filter(p => p.m >= 0.75 && p.m <= 1.25)
    .sort((a, b) => a.m - b.m);

  if (pts.length < 3) return;

  const maxIV = Math.max(...pts.map(p => p.iv)) * 1.08;
  const minIV = Math.max(0, Math.min(...pts.map(p => p.iv)) * 0.92);

  const xS = m  => p.l + ((m - 0.75) / 0.5) * (W - p.l - p.r);
  const yS = iv => H - p.b - ((iv - minIV) / (maxIV - minIV)) * (H - p.t - p.b);

  // Grid
  ctx.strokeStyle = '#0d1420'; ctx.lineWidth = 0.5;
  for (let i = 0; i <= 3; i++) {
    const y = p.t + (i / 3) * (H - p.t - p.b);
    ctx.beginPath(); ctx.moveTo(p.l, y); ctx.lineTo(W - p.r, y); ctx.stroke();
    const iv = maxIV - (i / 3) * (maxIV - minIV);
    ctx.fillStyle = '#2a3545'; ctx.font = '8px IBM Plex Mono'; ctx.textAlign = 'right';
    ctx.fillText((iv * 100).toFixed(0) + '%', p.l - 3, y + 3);
  }

  // ATM line
  const atmX = xS(1.0);
  ctx.setLineDash([2, 3]); ctx.strokeStyle = '#1c2535'; ctx.lineWidth = 0.8;
  ctx.beginPath(); ctx.moveTo(atmX, p.t); ctx.lineTo(atmX, H - p.b); ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle = '#2a3545'; ctx.font = '7px IBM Plex Mono'; ctx.textAlign = 'center';
  ctx.fillText('ATM', atmX, H - p.b + 10);

  // Fill puts (left of ATM) vs calls (right)
  const gradPut  = ctx.createLinearGradient(p.l, 0, atmX, 0);
  gradPut.addColorStop(0, 'rgba(192,57,43,0.2)');
  gradPut.addColorStop(1, 'rgba(192,57,43,0.04)');
  const gradCall = ctx.createLinearGradient(atmX, 0, W - p.r, 0);
  gradCall.addColorStop(0, 'rgba(42,157,111,0.04)');
  gradCall.addColorStop(1, 'rgba(42,157,111,0.14)');

  const leftPts  = pts.filter(q => q.m <= 1.0);
  const rightPts = pts.filter(q => q.m >= 1.0);

  const fillSmile = (pts, grad) => {
    if (pts.length < 2) return;
    ctx.beginPath();
    ctx.moveTo(xS(pts[0].m), H - p.b);
    pts.forEach(q => ctx.lineTo(xS(q.m), yS(q.iv)));
    ctx.lineTo(xS(pts[pts.length - 1].m), H - p.b);
    ctx.closePath(); ctx.fillStyle = grad; ctx.fill();
  };
  fillSmile(leftPts, gradPut);
  fillSmile(rightPts, gradCall);

  // Smile curve
  ctx.beginPath(); ctx.strokeStyle = '#c8a84b'; ctx.lineWidth = 1.5; ctx.lineJoin = 'round';
  pts.forEach((q, i) => i ? ctx.lineTo(xS(q.m), yS(q.iv)) : ctx.moveTo(xS(q.m), yS(q.iv)));
  ctx.stroke();

  // x axis labels
  [0.80, 0.90, 1.00, 1.10, 1.20].forEach(m => {
    if (xS(m) > p.l && xS(m) < W - p.r) {
      ctx.fillStyle = '#2a3545'; ctx.font = '7px IBM Plex Mono'; ctx.textAlign = 'center';
      ctx.fillText(Math.round(m * 100) + '%', xS(m), H - p.b + 10);
    }
  });
}

// ─── UI Helpers ───────────────────────────────────────────────────────────────
function setStatus(msg, type) {
  document.getElementById('status-text').textContent = msg;
  const d = document.getElementById('status-dot');
  d.className = 'tb-status-dot ' + type;
}

function setBar(pct) {
  const b = document.getElementById('ld-bar');
  if (b) b.style.width = pct + '%';
}

function showLoading(show) {
  document.getElementById('loading-overlay').classList.toggle('hidden', !show);
  if (!show) {
    document.getElementById('empty-state').style.display = 'none';
  }
}

function setT(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

function n2(v, d = 2) { return v == null || isNaN(v) ? '—' : Number(v).toFixed(d); }

function fmtCap(n) {
  if (n >= 1e12) return (n / 1e12).toFixed(2) + 'T';
  if (n >= 1e9)  return (n / 1e9).toFixed(2) + 'B';
  if (n >= 1e6)  return (n / 1e6).toFixed(1) + 'M';
  return n.toLocaleString();
}

function fmtVol(n) {
  if (n >= 1e9) return (n / 1e9).toFixed(1) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(0) + 'K';
  return n.toLocaleString();
}

function delay(ms) { return new Promise(r => setTimeout(r, ms)); }
