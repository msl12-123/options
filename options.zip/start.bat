@echo off
echo.
echo   IV Surface -- Derivatives Analytics
echo   -------------------------------------
echo.

where node >nul 2>&1
if %errorlevel% neq 0 (
  echo   ERROR: Node.js is not installed.
  echo.
  echo   Install it from https://nodejs.org  (LTS version recommended)
  echo.
  pause
  exit /b 1
)

echo   Starting server...
echo.
start "" http://localhost:3000
node server.js
